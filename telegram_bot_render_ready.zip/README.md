# BOLT Telegram Bot (Render Ready)
This bot is ready to deploy on https://render.com.

## Steps to Deploy:
1. Push this code to a GitHub repository.
2. Go to Render and create a new Web Service.
3. Set the Start Command to:
   ```
   python main_modified.py
   ```
4. Set environment variable `YOUR_BOT_TOKEN` with your bot token.
5. Deploy and enjoy!
